<?php
/**
 * Created by JetBrains PhpStorm.
 * User: heqing02
 * Date: 13-9-30
 * Time: 下午5:00
 * To change this template use File | Settings | File Templates.
 */
$arr = array();
$arr[] = array("dd"=>"dddddd");
$arr[] = ("vvv");
$arr[] = ("ddcccdd");
$arr[0]["mm"]="mmmm";
echo json_encode($arr);
